#!/usr/bin/perl

use strict; require q(../../AEACuS-master/aeacus.pl);

###############################
# SET USER SPECIFICATIONS BELOW
###############################

my $mode = 3;		# 0: N tasks on single CPUs; 1: 48 singlecore tasks on exclusive node; 2: 1 multicore task on exclusive node; 3: 1 multicore task on N CPUs
my $cycles = 4;		# specify number of times to iterate the full process cycle in outer loop
my $tasks = 1;		# specify number of tasks to broadcast across for mode 0 (forced to 48 for mode 1 or to 1 for modes 2/3)
my $cpus = 8;		# specify number of CPUs to share across single task for mode 3 (forced to 48 for mode 2 or to 1 for modes 0/1)
my $runs = 1;		# specify number of looped serial runs internal to run_core (usually 1)
my $events = 1000000;	# specify number of events generated per run (do not exceed 1 million)
my $jobn = "JOB_NAME";	# specify a job name

# list nodes to exclude or to require (leave nodelist empty to run on any node) 
my @exclude = (
	"lnxhpcnode04",
);
my @nodelist = (
#	"lnxhpcnode06",
);

# list the case-sensitive names of any channels to be generated from the CHANNELS folder
my (@channels) = (
	"AZJJ", "TTBarJJ", "TWJJ", "TauTauJJ", "WJJJ", "WWJJ", "WZJJ", "ZZJJ", "llJJJ", "TJJJ", "MulMulJJ",
#	"GluonDijet", "LightQuarkDijet", "CharmDijet", "BottomDijet", "TopDijet",
);

# list the case-sensitive names of any parameter cards to be run from the PARAM_CARDS folder 
my (%params) = (
	MulMulJJ => [
		"sl_110_n1_50", "sl_110_n1_60", "sl_110_n1_70", "sl_110_n1_80",
		"sl_160_n1_100", "sl_160_n1_110", "sl_160_n1_120", "sl_160_n1_130",
		"sl_300_n1_240", "sl_300_n1_250", "sl_300_n1_260", "sl_300_n1_270",
	],
);

# list the keys and values of run_card.dat parameters to be cycled for tranche generation
#my (@low) = ((25,50,100), &RANGE(250,1250,250), &RANGE(1500,4500,500), &RANGE(5000,9000,1000));
#my (@upp) = ((50,100,250), &RANGE(500,1500,250), &RANGE(2000,5000,500), &RANGE(6000,10000,1000));
my (@low) = ( 0, 300, 600, 1100, 1800, 2700, 3700 );
my (@upp) = ( 300, 600, 1100, 1800, 2700, 3700, -1 );
my (@tranche) = (
	[	ptl		=> [ 0.5 ]],
	[	ihtmin		=> [ @low ],
		ihtmax		=> [ @upp ],
#		pt_min_pdg	=> [ map { my ($v) = $_/2; +{ 5 => $v, 6 => $v, 21 => $v }} @low ], 
#		pt_max_pdg	=> [ map { my ($v) = $_/2; +{ 5 => $v, 6 => $v, 21 => $v }} @upp ],
	],
);
# format for a substitution specification is [ key => [ list of values ], ... ]
# if there are multiple keys in one specification then their lists must have
# ... a matched number of values and the nth values are grouped together
# if there are multiple specifications then key/value combinations are matrixed
# values which are themselves hash references { key => value, ... } are passed to MG as { key:value, ... }

############################
# END OF USER SPECIFICATIONS
############################

$mode = 0+(0..3)[$mode];

(@tranche) = map { join q( ), @$_ } &ASSIGNMENTS([
	map { (ref eq q(ARRAY)) or die "Invalid specification list construction";
		my ($keys,$vals) = @{ &SPANS( 2, $_ ) }; 
		(@$keys) or die "Empty key in tranche specification";
		(@$keys == @$vals) or die "Number of keys must match number of value lists";
		my ($n); for (@$vals) {
			(ref eq q(ARRAY)) or die "Invalid values list construction";
			(( $n ||= ( @$_ or die "Length of values list cannot be zero" )) == (@$_)) 
				or die "Lengths of values lists must match"; }
		[ map { my ($i) = $_; join q( ), map {( $$keys[$_], ( q(").( do { my ($v) = $$vals[$_][$i];
			((ref $v eq q(HASH)) ? ( q({).( join q(,), map { join q(:), ($_,$$v{$_}) } ( sort keys %$v )).q(})) : ($v))
				} ).q(")))} (0..(@$keys-1)) } (0..($n-1)) ]
	} (@tranche) ]);

open FHE, ">", "./submit_all.sh" or die;

my ($seed) = ( 0+( grep { chomp; 1 } `tail -n1 seed.txt 2>/dev/null` )[0] || 1 );

for (1..($cycles)) {
	for my $chn (@channels) {
		for my $param (@{ $params{$chn} || [ q(DEFAULT) ] }) {
			for my $tranche ((@tranche) ? (@tranche) : q()) { my ($runmode);
				print STDOUT +( my $name = join "_", ($chn,$param,$seed))."\n";
				open FHO, ">", "./BATCH/${name}.sh";
				print FHO "#!/bin/bash\n";
				print FHO "#SBATCH --job-name=${jobn}\n";
				print FHO "#SBATCH --output=./OUT/%x_%06j.out\n";
				print FHO "#SBATCH --error=./ERR/%x_%06j.err\n";
				if (@exclude) { print FHO "#SBATCH --exclude=".( join ",", @exclude )."\n"; }
				if (@nodelist) { print FHO "#SBATCH --nodelist=".( join ",", @nodelist )."\n"; }
				if ($mode == 3) { $runmode = 2; $tasks = 1;
					print FHO "#SBATCH --nodes=1\n";
					print FHO "#SBATCH --ntasks=1\n";
					print FHO "#SBATCH --cpus-per-task=${cpus}\n"; }
				elsif ($mode == 2) { $runmode = 2; $tasks = 1;
					print FHO "#SBATCH --exclusive\n";
					print FHO "#SBATCH --nodes=1\n";
					print FHO "#SBATCH --ntasks=1\n";
					print FHO "#SBATCH --cpus-per-task=48\n"; }
				elsif ($mode == 1) { $runmode = 0; $tasks = 48;
					print FHO "#SBATCH --exclusive\n";
					print FHO "#SBATCH --nodes=1\n";
					print FHO "#SBATCH --tasks-per-node=48\n";
					print FHO "#SBATCH --cpus-per-task=1\n"; }
				else { $runmode = 0;
					print FHO "#SBATCH --ntasks=${tasks}\n";
					print FHO "#SBATCH --cpus-per-task=1\n"; }
				print FHO "#SBATCH --mem-per-cpu=4G\n";
				print FHO "#SBATCH --partition=physics,normal\n";
				print FHO "#SBATCH --time=168:00:00\n";
				print FHO "srun -o ./OUT/%x_%06j_%03t.out -e ./ERR/%x_%06j_%03t.err ./SCRIPTS/run_core.sh " .
					"${chn} ${param} ${events} ${runs} ${seed} ${runmode} ${tranche}\n";
				print FHO "rm ./BATCH/${name}.sh\n";
				print FHO "exit 0\n";
				close FHO;
				print FHE "sbatch ./BATCH/${name}.sh\n";
				$seed += $tasks*$runs;
			}
		}
	}
}

close FHE; system( "chmod 750 ./submit_all.sh" );

system( "echo ${seed} >> seed.txt" );

1

