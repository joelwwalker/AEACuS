#!/usr/bin/perl

use strict; use sort qq(stable); use FindBin qw($Bin); use lib qq($Bin); require q(aeacus.pl); our ($OPT); $|++;

my ($fin,$out,$pre) = ( @ARGV );

$fin =~ /(?:^|\/)([^\/]+)\.lhe$/ or die q(bad file name for input);

open my $FHI, q(<), $fin or die q(cannot open file ${fin} for read);

( my ($h,$f) = ( &Local::FILE::NEXT([ ( &DEFINED($out,q(./LHCO))), [ ( &DEFINED($pre,$1)), 0, q(lhco) ]]))) or die q(cannot open file for output);

my ($xsc,@evt); while (<$FHI>) {
	next unless /^\s*<event>/;
	my ($lin) = ( scalar <$FHI> );
	next unless $lin =~ /^\s*\d+/;
	my ($obj) = [ map {(0+ $_ )} ( split q( ), $lin ) ];
	next unless ( @$obj == 6 );
	my ($wgt) = 0+$$obj[2];
	my ($met,$str,$i,@obj) = [0,0];
	while (<$FHI>) {
		last if /^\s*<\/event>/;
		next unless /^\s*(?:-|\+)?\d+/;
		my ($obj) = [ map {(0+ $_ )} ( split ) ];
		next unless (( @$obj == 13 ) && ( $$obj[1] == 1 ));
		my ($pid,$trk,$hft) = (5,0,0);
		LOOP: for my $pth ( [[22],[0,0,0]], [[11],[1,-1,0]], [[13],[2,-1,0]], [[15],[3,-1,0]], [[1,2,3,4],[4,1,0]], [[5,6],[4,1,1]], [[21],[4,0,0]] ) {
			for (@{$$pth[0]}) {
				next unless ( abs $$obj[0] == $_ );
				($pid,$trk,$hft) = (@{$$pth[1]});
				if ( $trk < 0 ) { $trk = ( $$obj[0] <=> 0 ); }
				last LOOP; }}
		push @obj, [ $pid, @{(( &ETA_PHI_PTM_MAS([ @$obj[(9,6..8)]] )) || (next))}[0..3], $trk, $hft, (( $pid == 4 ) ? (999.9) : (0)), 0, 0 ];
		if ( $pid == 5 ) { $$met[0] += $$obj[6]; $$met[1] += $$obj[7]; }}
	next unless @obj;
	$xsc += $wgt;
	push @obj, [ 6, 0, @{(( &ETA_PHI_PTM_MAS([ 0, @$met[0,1], 0 ])) || (next))}[1..2], 0, 0, 0, 0, 0, 0 ];
	for ( sort { $$a[0] <=> $$b[0] } @obj ) {
		$str .= ( sprintf qq(%4i %4i %8.3f %8.3f %7.2f %7.2f %6.1f %6.1f %7.2f %6.1f %6.1f\n), (++$i,@$_)); }
	push @evt, [ $wgt, $str ]; }

my $evt = 0+@evt or die q(no valid event records extracted from file ${fin});

#print qq(\n   #  typ      eta      phi      pt    jmas   ntrk   btag  had/em   dum1   dum2\n\n);

print qq(\n# ${evt} EVENT SAMPLE).(($evt==1) ? q() : q(S)).qq( PROCESSED IN TOTAL\n);

printf qq(\n# %+10.3E PB CROSS SECTION IMPLIES %+10.3E PER PB LUMINOSITY\n), (( &RATIO($xsc,$evt)), ( &RATIO($evt**2,$xsc)));

for my $i (1..(@evt)) { my ($wgt,$str) = @{$evt[$i-1]};
	printf qq(\n%4i %13d %8d      %10.3E\n), (0,$i,0,( &RATIO($wgt,$evt)));
	print $str; }

print qq(\n);

close ($h);

link ( $$f[0].$$f[1], qq(./).$$f[1] );

1

