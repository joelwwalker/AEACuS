#!/usr/bin/perl

use strict;

my $events = 1_000_000;

my @LHCO = do { opendir( my $LHCO, './LHCO' ) || die 'Cannot open directory ./LHCO: '.$!; sort grep { s/\.lhco$// } readdir( $LHCO ) };
my %CUTS = do { opendir( my $CUTS, './Cuts' ) || die 'Cannot open directory ./Cuts: '.$!; map {( $_ => 1 )} grep { s/\.cut$// } readdir( $CUTS ) };

for my $file (@LHCO) {
	unless ( delete $CUTS{$file} ) { print 'rm ./LHCO/'.$file.'.lhco'."\n"; next }
	my ($c1) = map {(0+$_)} ( `head -2 ./Cuts/${file}.cut | grep TOTAL` =~ m/^#?\s*(\d+)\s+/ );
	my ($c2) = map {(0+$_)} ( `head -2 ./Cuts/${file}.cut | grep TOTAL` =~ m/^#?\s*(\d+)\s+/ );
	if ( $c1 != $c2 ) { print $file.' has unmatched event counts in ./LHCO and ./Cuts'."\n" }
	if ( $c1 / $events < 0.8 ) { print $file.' has a low event count ('.$c1.'/'.$events.')'."\n" }}

for my $file ( sort keys %CUTS ) { print 'rm ./Cuts/'.$file.'.cut'."\n"; print 'rm ./Cuts/CHN_*/'.$file.'.cut'."\n" }

my @channels = qw( AZJJ TJJJ TTBarJJ TWJJ TauTauJJ WJJJJ WWJJ WZJJ ZZJJ llJJJ
	MulMulJJ_sl_110_n1_50 MulMulJJ_sl_110_n1_60 MulMulJJ_sl_110_n1_70 MulMulJJ_sl_110_n1_80
	MulMulJJ_sl_160_n1_100 MulMulJJ_sl_160_n1_110 MulMulJJ_sl_160_n1_120 MulMulJJ_sl_160_n1_130
	MulMulJJ_sl_300_n1_240 MulMulJJ_sl_300_n1_250 MulMulJJ_sl_300_n1_260 MulMulJJ_sl_300_n1_270 );
my @tranches = qw( 0 300 600 1100 1800 2700 3700 );

for my $c (@channels) {
	print 'CHN: '.$c."\n";
	for my $t (@tranches) {
		my $r = qr/^${c}_.*_htjmin_${t}_.*$/;
		print join "\t", ( q(), $t.':', 0+( grep { $_ =~ $r } @LHCO )); print "\n"; }}
 
