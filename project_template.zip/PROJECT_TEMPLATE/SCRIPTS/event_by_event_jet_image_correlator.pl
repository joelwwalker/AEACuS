#!/usr/bin/perl

use strict; use sort q(stable); use POSIX q(floor); use constant +{ PI => 4*( atan2 (1,1)) }; $|++;

my $fil = $ARGV[0]; ( my $out = q(PIXELS_).$fil ) =~ s/\.lhco/.csv/;

my $rad = 1.5;
my $pix = 30;
my $skip_events = 0;
my $use_objects = 25000;
my $eta_jet_cut = 4.5;
my $pt_lepton_cut = 10;
my $skipped_events = 0;
my ($lp,$lh) = (0,0);

my $dir = '/storage/archive/JWW004/QUARK_GLUON_JETS/LHCO';
open ( my $PART, '<', $dir.'/PARTON_'.$fil ) or die;
open ( my $HADR, '<', $dir.'/HADRON_'.$fil ) or die;
open ( my $FOUT, '>', './DATA/'.$out ) or die;

local $_; LOOP: while (<$PART>) {
	my @line = (split); next unless ( $line[0] eq '0' ); next if ( ++$lp <= $skip_events );
	my ($evt,$wgt,$met,@part) = @line[1,3];
	local $_; while (<$PART>) { my @line = (split);
		do { $met = $line[4]; last } if ( $line[1] eq '6' );
		next unless ( $line[1] eq '4' );
		push @part, [ map {(0+ $_)} @line[2..5] ]; }
	( @part == 2 ) or die;
	local $_; while (<$HADR>) { next unless (/^\s*0\s+(\d+)\s+/); next if ( ++$lh <= $skip_events );
		( $1 eq $evt ) or die 'EVENT NUMBER MISMATCH';
		my (@hadr); local $_; while (<$HADR>) { my @line = (split);
			last if ( $line[1] eq '6' ); next if ( $line[1] eq '0' );
			if ($line[1] ne '4') { if ( $line[4] > $pt_lepton_cut ) {
				$skipped_events++; next LOOP } next }
			push @hadr, [ map {(0+ $_)} @line[2..5] ]; }
		for (@part) { my ($peta,$pphi,$pptm,$pmas) = @$_;
			next if ((( abs $peta ) + $rad ) > $eta_jet_cut ); if ($pphi < 0) { $pphi += 2*PI }
			last LOOP if ( $use_objects-- == 0 ); my @pix = ((0)x($pix*$pix));
			for (@hadr) { my ($heta,$hphi,$hptm,$hmas) = @$_; if ($hphi < 0) { $hphi += 2*PI }
				my $beta = floor (( 1 + ( $heta - $peta )/($rad))*($pix/2));
				next if (($beta < 0) or ($beta >= $pix));
				my $bphi = floor (( 1 + (( map {(((abs) <= PI ) ? ($_) : ( $_ - 2*PI*($_<=> 0)))} ( $hphi - $pphi ))[0] )/($rad))*($pix/2));
				next if (($bphi < 0) or ($bphi >= $pix));
				$pix[$pix*$bphi+$beta] += $hptm; }
			# print $FOUT +( join ',', (($pix,$rad,$wgt,0+@part,$met,$peta,$pphi,$pptm,$pmas), @pix )), "\n"; }
			print $FOUT +( join ',', @pix ), "\n"; }
		next LOOP; }}

# print STDOUT $skipped_events." SKIPPED EVENTS\n";

1

