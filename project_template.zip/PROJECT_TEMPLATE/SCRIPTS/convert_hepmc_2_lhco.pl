#!/usr/bin/perl

use strict; use sort qq(stable); use Fcntl qw(:seek); use FindBin qw($Bin); use lib qq($Bin); require q(aeacus.pl); our ($OPT); $|++;

my ($fin,$out,$pre) = ( @ARGV );

(( $fin =~ /(?:^|\/)([^\/]+)\.hepmc$/ ) or ( die q(bad file name for input)));

(( open my $FHI, q(<), $fin ) or ( die qq(cannot open file ${fin} for read)));

(( my ($FHO,$FIL) = ( &Local::FILE::NEXT([ ( &DEFINED($out,q(./LHCO))), [ ( &DEFINED($pre,$1)), 0, q(lhco) ]]))) or ( die q(cannot open file for output)));

my ($FHT) = ( grep {((defined) or ( die q(Cannot open temporary file for read/write)))} ( &Local::FILE::HANDLE()));

my ($xsc,$evt); do { my ($wgt,$met,@obj); local ($_); while (<$FHI>) {
	if ( m/^(?:(E)|HepMC::IO_GenEvent-(?:END|START)_EVENT_LISTING)\b/ ) {
		if ((@obj) && ( defined $wgt )) {
			push @obj, [ 6, 0, @{(( &ETA_PHI_PTM_MAS([ 0, @{$met||[0,0]}[0,1], 0 ])) || (next))}[1..2], 0, 0, 0, 0, 0, 0 ];
			printf ( qq(\n%4i %13d %8d      %10.3E\n), ( 0, ++$evt, 0, $wgt ));
			my ($i); for ( sort { $$a[0] <=> $$b[0] } @obj ) {
				printf ( qq(%4i %4i %8.3f %8.3f %7.2f %7.2f %6.1f %6.1f %7.2f %6.1f %6.1f\n), ( ++$i, @$_ )); }
			$xsc += $wgt; ($wgt,$met,@obj) = (); }
		if ($1) { $wgt = (0+ (split)[-1] ); }}
	elsif ( m/^P\s/ ) {
		my ($obj) = [ map {(0+ $_ )} ( split ) ];
		next unless (( @$obj >= 13 ) && ( $$obj[8] == 1 ));
# JET KLUDGE
		my ($pid,$trk,$hft) = (4,0,0);
#		my ($pid,$trk,$hft) = (5,0,0);
		LOOP: for my $pth ( [[22],[0,0,0]], [[11],[1,-1,0]], [[13],[2,-1,0]], [[15],[3,-1,0]],
				[[1,2,3,4],[4,1,0]], [[5,6],[4,1,1]], [[21],[4,0,0]], [[12,14,16],[5,0,0]] ) {
			for (@{$$pth[0]}) {
				next unless (( abs $$obj[2] ) == $_ );
				($pid,$trk,$hft) = (@{$$pth[1]});
				if ( $trk < 0 ) { $trk = ( $$obj[2] <=> 0 ); }
				last LOOP; }}
		push @obj, [ $pid, @{(( &ETA_PHI_PTM_MAS([ @$obj[(6,3..5)]] )) || (next))}[0..3], $trk, $hft, (( $pid == 4 ) ? (999.9) : (0)), 0, 0 ];
		if ( $pid == 5 ) { $met ||= [0,0]; $$met[0] += $$obj[3]; $$met[1] += $$obj[4]; }}}};

(($evt) or ( die qq(no valid event records extracted from file ${fin})));

(( seek $FHT, 0, SEEK_SET ) or ( die q(Cannot rewind temporary file))); ( select $FHO );

#print qq(\n   #  typ      eta      phi      pt    jmas   ntrk   btag  had/em   dum1   dum2\n\n);

print qq(\n# ${evt} EVENT SAMPLE).(($evt==1) ? q() : q(S)).qq( PROCESSED IN TOTAL\n);

printf ( qq(\n# %+10.3E PB CROSS SECTION IMPLIES %+10.3E PER PB LUMINOSITY\n), ((0+ $xsc), ( &RATIO($evt,$xsc))));

local ($_); while (<$FHT>) {( print )}

print qq(\n);

close ($FHT); close ($FHO);

link ( $$FIL[0].$$FIL[1], qq(./).$$FIL[1] );

1

