#!/bin/bash

shopt -s nullglob

WORK_DIR=${PWD}

REGEX="^(/storage/performance/[^/]+)/"

if [[ ! ${WORK_DIR} =~ ${REGEX} ]]; then
	echo "WORKING DIRECTORY ${WORK_DIR} IS NOT A SUBDIRECTORY OF /storage/performance/"
	exit 101
fi

BASE_DIR=${BASH_REMATCH[1]}

if [[ ! -d ${BASE_DIR} ]]; then
	echo "BASE DIRECTORY CANNOT BE ESTABLISHED"
	exit 102
fi

AEACuS_DIR="${BASE_DIR}/AEACuS-master"

if [[ -z ${AEACuS_DIR} ]]; then
	echo "CANNOT LOCATE AEACuS INSTALLATION IN BASE DIRECTORY ${BASE_DIR}"
	exit 103
fi

MG5_DIR=""

for DIR in "${BASE_DIR}/"*; do
	if [[ -d ${DIR} ]] && [[ ${DIR} == "${BASE_DIR}/MG5_aMC_"* ]]; then
		if [[ -n ${MG5_DIR} ]]; then
			echo "LOCATED MULTIPLE MADGRAPH INSTALLATIONS IN BASE DIRECTORY ${BASE_DIR}"
		fi
		MG5_DIR=${DIR}
	fi
done

if [[ -z ${MG5_DIR} ]]; then
	echo "CANNOT LOCATE MADGRAPH INSTALLATION IN BASE DIRECTORY ${BASE_DIR}"
	exit 104
fi

CHANNEL=${1}

PARAM=${2:-DEFAULT}

EVENTS=${3:-100000}

RUNS=${4:-1}

SEED=${5:-0}

MODE=${6:-0}

CPUS=${7:-None}

ENERGY=${8:-14}

if [[ ! ${ENERGY} =~ ^[1-9][0-9]*$ ]]; then
	echo "INVALID COLLISION ENERGY ${ENERGY}"
	exit 105
fi

BEAM=$(( ${ENERGY} * 1000 / 2 ))

if [[ ${SEED} != "0" ]]; then
	SEED=$(( ${SEED} + ${RUNS} * ${SLURM_PROCID} ))
fi

TASK_ID="$( printf %06d ${SLURM_JOBID} )_$( printf %03d ${SLURM_PROCID} )"

if [[ -z ${CHANNEL} ]]; then
	echo "NO CHANNEL SPECIFIED"
	exit 106
fi

if [[ ! -d "./CHANNELS/${CHANNEL}" ]]; then
	echo "COULD NOT ACCESS CHANNEL CHANNELS/${CHANNEL}"
	exit 107
fi

TAG=${CHANNEL}

if [[ ${PARAM} != "DEFAULT" ]]; then
	TAG="${TAG}_${PARAM}"
	if [[ ! -f "./PARAM_CARDS/${PARAM}.dat" ]]; then
		echo "COULD NOT ACCESS PARAMETER CARD PARAM_CARDS/${PARAM}.dat"
		exit 108
	fi
fi

if [[ -d "./RUNS/${TASK_ID}" ]]; then
	echo "DIRECTORY RUNS/${TASK_ID} ALREADY EXISTS"
	exit 109
fi

cp -r "./CHANNELS/${CHANNEL}/" "./RUNS/${TASK_ID}/"

cp ./Cards/* "./RUNS/${TASK_ID}/Cards/" 2>/dev/null

if [[ ${PARAM} != "DEFAULT" ]]; then
	cp "./PARAM_CARDS/${PARAM}.dat" "./RUNS/${TASK_ID}/Cards/param_card.dat"
fi

cp "${AEACuS_DIR}/aeacus.pl" "./RUNS/${TASK_ID}/bin/internal/"

cd "./RUNS/${TASK_ID}/"

if [[ -f "./Cards/pythia8_card_${CHANNEL}.dat" ]]; then
	cp "./Cards/pythia8_card_${CHANNEL}.dat" ./Cards/pythia8_card.dat
fi

sed -i.bak -E -e "s/(.*)=[[:space:]]*os\.popen\(.*/\1= 20, 80 /" ./bin/internal/extended_cmd.py

if [[ -f "./Cards/me5_configuration.txt" ]]; then
	sed -i.bak -E -e "s/.*run_mode[[:space:]]*=.*/ run_mode = ${MODE} /" ./Cards/me5_configuration.txt
	sed -i.bak -E -e "s/.*nb_core[[:space:]]*=.*/ nb_core = ${CPUS} /" ./Cards/me5_configuration.txt
else
	sed -i.bak -E -e "s/.*run_mode[[:space:]]*=.*/ run_mode = ${MODE} /" ./Cards/amcatnlo_configuration.txt
	sed -i.bak -E -e "s/.*nb_core[[:space:]]*=.*/ nb_core = ${CPUS} /" ./Cards/amcatnlo_configuration.txt
fi

rm ./Cards/madanalysis5*card.dat 2>/dev/null

for (( i=9; i<${#}; i+=2 )); do
	KEY="${@:${i}:1}"
	VAL="${@:$(( ${i} + 1 )):1}";
	sed -i.bak -E -e "s/.*=[[:space:]]*${KEY}([^[:alnum:]]|$)/ ${VAL} = ${KEY}\1/" ./Cards/run_card.dat
	VAL="${VAL/#-/N}"; VAL="${VAL/./P}"; VAL="${VAL//[\}\{\:\,]/_}"
	TAG="${TAG}_${KEY}_${VAL}"
done

TAG="${TAG//[^A-Za-z0-9_-]}_${ENERGY}TeV"

export LC_ALL=C
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${MG5_DIR}/HEPTools/lhapdf6/lib"
sed -i.bak -E -e "s/.*=[[:space:]]*run_tag([^[:alnum:]]|$)/ ${TAG} = run_tag\1/" ./Cards/run_card.dat
sed -i.bak -E -e "s/.*=[[:space:]]*nevents([^[:alnum:]]|$)/ ${EVENTS} = nevents\1/" ./Cards/run_card.dat
sed -i.bak -E -e "s/.*=[[:space:]]*ebeam1([^[:alnum:]]|$)/ ${BEAM}.0 = ebeam1\1/" ./Cards/run_card.dat
sed -i.bak -E -e "s/.*=[[:space:]]*ebeam2([^[:alnum:]]|$)/ ${BEAM}.0 = ebeam2\1/" ./Cards/run_card.dat

if [[ -f ./Cards/shower_card.dat ]]; then
	export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${MG5_DIR}/HEPTools/zlib/lib"
	# sed -i.bak -E -e "s/.*=[[:space:]]*event_norm([^[:alnum:]]|$)/ sum = event_norm\1/" ./Cards/run_card.dat
	sed -i.bak -E -e "s/.*=[[:space:]]*parton_shower([^[:alnum:]]|$)/ PYTHIA8 = parton_shower\1/" ./Cards/run_card.dat
	sed -i.bak -E -e "s/(EXTRALIBS[[:space:]]*=)[[:space:]]*/\1 z dl /" ./Cards/shower_card.dat
fi

rm ./Cards/*.bak 2>/dev/null

# sleep $[ ( $RANDOM % 20 ) + 2 ]s

for (( i=1; i<=${RUNS}; i++ )); do
	sed -i.bak -E -e "s/.*=[[:space:]]*iseed([^[:alnum:]]|$)/ ${SEED} = iseed\1/" ./Cards/run_card.dat
	rm ./Cards/*.bak 2>/dev/null
	python2 ./bin/generate_events -f
	# rm ./Events/*/*.hepmc.gz 2>/dev/null
	SEED=$(( ${SEED} + 1 ))
done

##########################################
# HANDLE PROCESSING OF RECO LEVEL EVENT
##########################################
if [[ -f ./Cards/cut_card.dat ]]; then

	rm ./Events/*.lhco 2>/dev/null

	for FIL in ./Events/*/events_PYTHIA8_*.hepmc*; do
		if [[ $FIL == *.gz ]]; then gunzip $FIL; fi
		"${MG5_DIR}/Delphes/DelphesHepMC" ../../Cards/delphes_card.dat "${FIL%events*}${TAG}_delphes_events.root" "${FIL%.gz}" 2>/dev/null
	done

	./bin/internal/aeacus.pl

fi
##########################################

##########################################
# HANDLE PROCESSING OF HARD PARTONIC EVENT
##########################################
if [[ -f ./Cards/cut_card_parton.dat ]]; then

	cp ../../SCRIPTS/convert_unweighted_lhe_2_lhco.pl ./bin/internal/

	rm ./PARTON_*.lhco 2>/dev/null

	for FIL in ./Events/*/unweighted_events.lhe* ./Events/*/events.lhe*; do
		if [[ $FIL == *.gz ]]; then gunzip $FIL; fi
		./bin/internal/convert_unweighted_lhe_2_lhco.pl "${FIL%.gz}" ../../LHCO "PARTON_${TAG}"
	done

	for FIL in ./PARTON_*.lhco; do
		./bin/internal/aeacus.pl ./Cards/cut_card_parton.dat "${FIL}"
	done

fi
##########################################

##########################################
# HANDLE PROCESSING OF HADRON-LEVEL EVENT
# ./Cards/pythia8_card.dat requires: HEPMCoutput:file = auto
##########################################
if [[ -f ./Cards/cut_card_hadron.dat ]]; then

	cp ../../SCRIPTS/convert_hepmc_2_lhco.pl ./bin/internal/

	rm ./HADRON_*.lhco 2>/dev/null

	for FIL in ./Events/*/*_pythia8_events.hepmc* ./Events/*/events_PYTHIA8_*.hepmc*; do
		if [[ $FIL == *.gz ]]; then gunzip $FIL; fi
		./bin/internal/convert_hepmc_2_lhco.pl "${FIL%.gz}" ../../LHCO "HADRON_${TAG}"
	done

	for FIL in ./HADRON_*.lhco; do
		./bin/internal/aeacus.pl ./Cards/cut_card_hadron.dat "${FIL}"
	done

fi
##########################################

cd ${WORK_DIR}

# COMMENT FOLLOWING LINE TO RETAIN RUN DIRECTORIES FOR DEBUGGING 
rm -rf "./RUNS/${TASK_ID}/" 2>/dev/null

