#!/bin/bash

rm -rf BATCH/* RUNS/* LHCO/* Cuts/* Plots/* OUT/* ERR/* submit_all.sh seed.txt

