#!/usr/bin/perl

use strict; use sort q(stable); use POSIX q(floor);
use FindBin qw($Bin); use lib qq($Bin); require q(aeacus.pl);
use constant { PI => 4*( atan2 (1,1)) }; $|++;

my $rad = 1.5;
my $pix = 30;
my $dir = './DATA';

opendir DHI, $dir or die;

for my $file ( grep {/\.csv$/} readdir( DHI )) {
	next unless $file =~ $ARGV[0]; ( my $sift = $file ) =~ s/^PIXELS/SIFT/g;
	open my $FHI, '<', $dir.'/'.$file;
	open my $FHO, '>', $dir.'/'.$sift;
	local $_; while (<$FHI>) { chop;
		my (@pix,@j) = ( split ',' );
		for my $i (0..(@pix-1)) { next unless $pix[$i];
			my ($eta,$phi,$ptm,$mas) = (( map {(($rad)*(( 2*$_+1 )/$pix - 1 ))}
				(( $i % $pix ),( floor ( $i / $pix )))), 0+( $pix[$i] ), 0 );
			my $tht = 2*atan2(exp(-1*$eta),1);
		        my @p = ($ptm*cos($phi),$ptm*sin($phi),$ptm*cos($tht)/sin($tht));
			my $e = sqrt($mas**2 + $p[0]**2 + $p[1]**2 + $p[2]**2);
			push @j, [($e,@p)]; }
		print $FHO +( join q(,), ( map {((defined) ? ( sprintf q(%+10.3E), $_ ) : q(NaN))} @{ &H( @j ) } ))."\n"; }}

sub H {
	my (@vcts,@rnk) = ( &LORENTZ_HASH(undef,@_)); my ($blk) = 3;
	my ($obj) = (( &Local::TREE::NEW( [[(undef),(undef),-1], (undef), [0,2*PI,+1]], ($blk), (-1),
		( sub { my ($ep0,$ep3,$phi) = @{(shift)}{( qw ( ep0 ep3 phi ))}; my ($a,$b) = (log($ep0+$ep3),log($ep0-$ep3)); [($a+$b)/2,($a-$b)/2,$phi] } ),
		( sub {( scalar &LORENTZ_HASH((undef), ( scalar &::LORENTZ_SUM((undef), ( map {($$_{RAW})} (@_))))))} ),
		( sub { use Math::Trig; my ($a,$b) = (shift,shift); my (@del) = (( 1 - (( tanh($$b[0]-$$a[0]))**2)),( cosh($$b[1]-$$a[1])),( cos($$b[2]-$$a[2])));
			my ($cof) = ( &::PRODUCT( map {(( &::ISA( 1, $_, q(Local::TREE::LEAF))) ? ( map { my ($mas,$ptm) = @{$_}{( qw ( mas ptm ))};
				( 1 / sqrt( 1 + (($mas/$ptm)**(2)))) } ( ${(($$_{PRM}) or ($_))}{RAW} )) : (( $del[2] <= 0 ) ? (0) : (1)))} ($a,$b)));
				((( $del[1] - ($cof*$del[2]))*( sqrt($del[0]))),$del[0]) } ), (undef))) or (die));
	$obj->GRAFT(@vcts); while (((($obj)->LEAVES()) > 0 ) && ( my ($slf,$nbr,$rsq,$rnk) = (($obj)->NEIGHBORHOOD()))) { push @rnk, $rnk; $slf->MERGE($nbr); }
	# print join "\n", map {%$_} map {($$_{RAW})} (($obj)->LEAVES());
	[ (( reverse @rnk ),(undef))[0..9]] }

1

