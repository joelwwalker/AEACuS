#!/bin/bash

#for key in Gluon Light Charm Bottom Top; do
for key in Top; do
	for file in /storage/archive/JWW004/QUARK_GLUON_JETS/LHCO/${key}*; do
		fb=$( basename $file )
		if [[ $fb == @(PARTON|HADRON)_* ]]; then continue; fi
		nohup ./SCRIPTS/event_by_event_jet_image_correlator.pl $fb &
	done
done

