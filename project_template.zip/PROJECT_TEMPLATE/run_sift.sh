#for f in ./DATA/FIVE_STATE_CLASSIFICATION/CALORIMETER_PIXELS/*.csv; do
for f in ./DATA/*.csv; do
	nohup ./SCRIPTS/sift_calculator.pl $(basename "$f") &
done
