
Code for AEACuS, RHADAManTHUS, & MInOS is maintained here: https://github.com/joelwwalker/AEACuS

A Quick-Start Demo is archived here: https://indico.cern.ch/event/1076291/contributions/4609972/

A video recording of the hour-long live tutorial session is available at the same address

A shorter summary of program design and operations is availble here: https://indico.cern.ch/event/1076291/contributions/4589238/

Code and Cards have been updated slightly relative to the presentation at CompTools2021

